# Legacy Wall Charts — Master Cumulative v0.9.0

This archive supersedes `LegacyWallCharts_Master_v0.8.9` and the older
`Dev2-Master-Cumulative-Beta-Build-5-Tournament-Studio` archive.

## Source checkpoint

- Repository: `Casanova-1066/legacy-wall-charts-preview-v2`
- Production branch: `main`
- Production checkpoint: `b50d7774de65c4d9edab3859171a29197b2c16a5`
- Packaged: 8 August 2026

## Included cumulative work

- Tournament Studio and the prior Beta Build 5 cumulative source
- Champions League historical archive containing 71 seasons
- Historical competition and season routes
- Completed Stripe checkout, subscription and entitlement fulfilment code
- Neon schema and migrations `0001` through `0015`
- Blood Oath Legacy logos and brand-reference artwork
- Absolute production asset paths for direct/deep links
- Legacy service-worker and poisoned-cache cleanup
- Vercel no-store rules for Historical pages and the service worker

## Safe replacement notes

- No `.env` files, credentials, Git history, `node_modules`, or generated
  `dist` output are included.
- Install with `npm ci`.
- Validate with `npm run typecheck` and `npm run build`.
- Vercel and Neon environment variables must remain configured in the hosting
  project; they are deliberately not embedded in this archive.
